# yolov5-demo > 2025-04-16 1:19pm
https://universe.roboflow.com/khushi-tlcn3/yolov5-demo-kinyf

Provided by a Roboflow user
License: CC BY 4.0

